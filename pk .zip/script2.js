const products = [
    { id: 1, brand: "ASUS", name: "ASUS ROG Strix G16", description: "Игровой ПК с RTX 4070", price: 189000, year: 2024, rating: 4.9, reviews: 124, category: "gaming", badge: "hot", specs: ["i7-13700K", "RTX 4070", "32GB DDR5", "1TB SSD"], img: "https://images.unsplash.com/photo-1587202372775-e229f172b9d7?w=600", full: { cpu: "Intel Core i7-13700K", gpu: "NVIDIA RTX 4070 12GB", ram: "32 ГБ DDR5", storage: "1 ТБ NVMe SSD", psu: "850W Gold", os: "Windows 11 Pro" } },
    { id: 2, brand: "MSI", name: "MSI MEG Trident X2", description: "Компактный игровой ПК с RTX 4080", price: 289000, year: 2024, rating: 4.9, reviews: 87, category: "gaming", badge: "hot", specs: ["i9-13900K", "RTX 4080", "32GB DDR5", "2TB SSD"], img: "https://images.unsplash.com/photo-1591488320449-011701bb6704?w=600", full: { cpu: "Intel Core i9-13900K", gpu: "NVIDIA RTX 4080 16GB", ram: "32 ГБ DDR5 6000MHz", storage: "2 ТБ NVMe SSD", psu: "1000W Platinum", os: "Windows 11 Pro" } },
    { id: 3, brand: "Corsair", name: "Corsair Vengeance i7400", description: "Мощный игровой ПК с подсветкой RGB", price: 215000, year: 2024, rating: 4.7, reviews: 64, category: "gaming", badge: "new", specs: ["i7-13700KF", "RTX 4070 Ti", "32GB DDR5", "1TB SSD"], img: "https://images.unsplash.com/photo-1547082299-de196ea013d6?w=600", full: { cpu: "Intel Core i7-13700KF", gpu: "NVIDIA RTX 4070 Ti 12GB", ram: "32 ГБ DDR5", storage: "1 ТБ NVMe SSD", psu: "850W Gold", os: "Windows 11 Home" } },
    { id: 4, brand: "HP", name: "HP Omen 45L", description: "Мощная игровая станция с отличным охлаждением", price: 245000, year: 2024, rating: 4.7, reviews: 78, category: "gaming", badge: null, specs: ["i7-13700K", "RTX 4070 Ti", "32GB", "2TB SSD"], img: "https://images.unsplash.com/photo-1593640408182-31c70c8268f5?w=600", full: { cpu: "Intel Core i7-13700K", gpu: "NVIDIA RTX 4070 Ti 12GB", ram: "32 ГБ DDR5", storage: "2 ТБ NVMe", psu: "1000W Gold", os: "Windows 11 Home" } },
    { id: 5, brand: "Alienware", name: "Alienware Aurora R15", description: "Легендарный игровой ПК от Alienware", price: 329000, year: 2024, rating: 4.8, reviews: 112, category: "gaming", badge: "hot", specs: ["i9-13900F", "RTX 4080", "32GB DDR5", "2TB SSD"], img: "https://images.unsplash.com/photo-1587202372775-e229f172b9d7?w=600", full: { cpu: "Intel Core i9-13900F", gpu: "NVIDIA RTX 4080 16GB", ram: "32 ГБ DDR5 5200MHz", storage: "2 ТБ NVMe SSD", psu: "1000W", os: "Windows 11 Pro" } },
    { id: 6, brand: "ASUS", name: "ASUS ROG G22CH", description: "Компактный игровой ПК с RTX 4060 Ti", price: 159000, year: 2024, rating: 4.6, reviews: 93, category: "gaming", badge: null, specs: ["i5-13400F", "RTX 4060 Ti", "16GB DDR5", "1TB SSD"], img: "https://images.unsplash.com/photo-1591488320449-011701bb6704?w=600", full: { cpu: "Intel Core i5-13400F", gpu: "NVIDIA RTX 4060 Ti 8GB", ram: "16 ГБ DDR5", storage: "1 ТБ NVMe SSD", psu: "650W Bronze", os: "Windows 11 Home" } },
    { id: 7, brand: "Acer", name: "Acer Predator Orion 7000", description: "Флагманский игровой ПК с RTX 4090", price: 489000, year: 2024, rating: 5.0, reviews: 41, category: "gaming", badge: "new", specs: ["i9-13900K", "RTX 4090", "64GB DDR5", "4TB SSD"], img: "https://images.unsplash.com/photo-1587202372775-e229f172b9d7?w=600", full: { cpu: "Intel Core i9-13900K", gpu: "NVIDIA RTX 4090 24GB", ram: "64 ГБ DDR5 6000MHz", storage: "4 ТБ NVMe SSD", psu: "1200W Platinum", os: "Windows 11 Pro" } },
    { id: 8, brand: "NZXT", name: "NZXT Player Three", description: "Стильный игровой ПК с чистым дизайном", price: 199000, year: 2024, rating: 4.8, reviews: 57, category: "gaming", badge: null, specs: ["i7-13700KF", "RTX 4070", "32GB DDR5", "1TB SSD"], img: "https://images.unsplash.com/photo-1547082299-de196ea013d6?w=600", full: { cpu: "Intel Core i7-13700KF", gpu: "NVIDIA RTX 4070 12GB", ram: "32 ГБ DDR5", storage: "1 ТБ NVMe SSD", psu: "750W Gold", os: "Windows 11 Home" } },
    { id: 9, brand: "Apple", name: "MacBook Pro 16 M3 Max", description: "Ноутбук для профессионалов с чипом M3 Max", price: 349000, year: 2024, rating: 5.0, reviews: 89, category: "laptop", badge: "new", specs: ["M3 Max", "48GB", "1TB SSD", "16\""], img: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=600", full: { cpu: "Apple M3 Max 16-core", gpu: "40-core GPU", ram: "48 ГБ Unifed", storage: "1 ТБ SSD", psu: "140W USB-C", os: "macOS Sonoma" } },
    { id: 10, brand: "MSI", name: "MSI Titan GT77", description: "Топовый игровой ноутбук с RTX 4090", price: 459000, year: 2024, rating: 4.8, reviews: 56, category: "laptop", badge: "hot", specs: ["i9-13980HX", "RTX 4090", "64GB DDR5", "4TB SSD"], img: "https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=600", full: { cpu: "Intel Core i9-13980HX", gpu: "NVIDIA RTX 4090 16GB", ram: "64 ГБ DDR5", storage: "4 ТБ NVMe SSD", psu: "330W", os: "Windows 11 Pro" } },
    { id: 11, brand: "ASUS", name: "ASUS Zenbook 14 OLED", description: "Тонкий премиальный ноутбук", price: 119000, year: 2024, rating: 4.7, reviews: 132, category: "laptop", badge: null, specs: ["Ryzen 7 8840HS", "16GB", "1TB SSD", "14\" OLED"], img: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=600", full: { cpu: "AMD Ryzen 7 8840HS", gpu: "Radeon 780M", ram: "16 ГБ LPDDR5", storage: "1 ТБ NVMe SSD", display: "14\" 3K OLED", os: "Windows 11 Home" } },
    { id: 12, brand: "Lenovo", name: "Lenovo Legion Pro 7", description: "Игровой ноутбук с RTX 4080", price: 289000, year: 2024, rating: 4.8, reviews: 74, category: "laptop", badge: "hot", specs: ["i9-13900HX", "RTX 4080", "32GB DDR5", "2TB SSD"], img: "https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=600", full: { cpu: "Intel Core i9-13900HX", gpu: "NVIDIA RTX 4080 12GB", ram: "32 ГБ DDR5 5600MHz", storage: "2 ТБ NVMe SSD", display: "16\" 2.5K 240Hz", os: "Windows 11 Pro" } },
    { id: 13, brand: "Dell", name: "Dell XPS 15", description: "Премиальный ультрабук с 4K дисплеем", price: 229000, year: 2024, rating: 4.6, reviews: 61, category: "laptop", badge: null, specs: ["i7-13700H", "RTX 4060", "32GB", "1TB SSD"], img: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=600", full: { cpu: "Intel Core i7-13700H", gpu: "NVIDIA RTX 4060 8GB", ram: "32 ГБ DDR5", storage: "1 ТБ NVMe SSD", display: "15.6\" 4K OLED", os: "Windows 11 Pro" } },
    { id: 14, brand: "Dell", name: "Dell OptiPlex 7010", description: "Надёжный офисный компьютер", price: 65000, year: 2024, rating: 4.5, reviews: 210, category: "work", badge: null, specs: ["i5-13500", "16GB", "512GB SSD", "UHD 770"], img: "https://images.unsplash.com/photo-1593640408182-31c70c8268f5?w=600", full: { cpu: "Intel Core i5-13500", gpu: "Intel UHD 770", ram: "16 ГБ DDR4", storage: "512 ГБ SSD", psu: "300W", os: "Windows 11 Pro" } },
    { id: 15, brand: "ASUS", name: "ASUS ProArt Station", description: "Рабочая станция для дизайнеров", price: 298000, year: 2024, rating: 4.8, reviews: 34, category: "work", badge: null, specs: ["i9-13900K", "RTX 4080", "64GB", "4TB SSD"], img: "https://images.unsplash.com/photo-1547082299-de196ea013d6?w=600", full: { cpu: "Intel Core i9-13900K", gpu: "NVIDIA RTX 4080 16GB", ram: "64 ГБ DDR5", storage: "4 ТБ NVMe RAID", psu: "1000W Platinum", os: "Windows 11 Pro" } },
    { id: 16, brand: "Acer", name: "Acer Aspire TC", description: "Доступный ПК для повседневных задач", price: 42000, year: 2024, rating: 4.3, reviews: 156, category: "work", badge: null, specs: ["i3-13100", "8GB", "256GB SSD", "UHD 730"], img: "https://images.unsplash.com/photo-1593640408182-31c70c8268f5?w=600", full: { cpu: "Intel Core i3-13100", gpu: "Intel UHD 730", ram: "8 ГБ DDR4", storage: "256 ГБ SSD", psu: "250W", os: "Windows 11 Home" } },
    { id: 17, brand: "HP", name: "HP Z2 Tower G9", description: "Профессиональная рабочая станция", price: 145000, year: 2024, rating: 4.7, reviews: 42, category: "work", badge: "new", specs: ["Xeon W3", "RTX A2000", "32GB ECC", "1TB SSD"], img: "https://images.unsplash.com/photo-1593640408182-31c70c8268f5?w=600", full: { cpu: "Intel Xeon W3-2423", gpu: "NVIDIA RTX A2000 12GB", ram: "32 ГБ DDR5 ECC", storage: "1 ТБ NVMe SSD", psu: "700W", os: "Windows 11 Pro" } },
    { id: 18, brand: "Lenovo", name: "Lenovo ThinkStation P360", description: "Надёжная станция для инженерных задач", price: 178000, year: 2024, rating: 4.6, reviews: 29, category: "work", badge: null, specs: ["i7-13700", "RTX A4000", "32GB", "1TB SSD"], img: "https://images.unsplash.com/photo-1547082299-de196ea013d6?w=600", full: { cpu: "Intel Core i7-13700", gpu: "NVIDIA RTX A4000 16GB", ram: "32 ГБ DDR5", storage: "1 ТБ NVMe SSD", psu: "750W", os: "Windows 11 Pro" } },
    { id: 19, brand: "Lenovo", name: "Lenovo IdeaCentre AIO", description: "Стильный моноблок для дома", price: 89000, year: 2024, rating: 4.6, reviews: 45, category: "monoblock", badge: "new", specs: ["Ryzen 7", "16GB", "1TB SSD", "27\""], img: "https://images.unsplash.com/photo-1547082299-de196ea013d6?w=600", full: { cpu: "AMD Ryzen 7 7735HS", gpu: "Radeon 680M", ram: "16 ГБ DDR5", storage: "1 ТБ SSD", psu: "150W", os: "Windows 11 Home" } },
    { id: 20, brand: "Apple", name: "iMac 24 M3", description: "Стильный моноблок с чипом M3", price: 179000, year: 2024, rating: 4.9, reviews: 92, category: "monoblock", badge: "new", specs: ["M3", "16GB", "512GB SSD", "24\" Retina"], img: "https://images.unsplash.com/photo-1547082299-de196ea013d6?w=600", full: { cpu: "Apple M3 8-core", gpu: "10-core GPU", ram: "16 ГБ Unified", storage: "512 ГБ SSD", display: "24\" 4.5K Retina", os: "macOS Sonoma" } },
    { id: 21, brand: "HP", name: "HP Envy 34 All-in-One", description: "Широкий моноблок для творчества", price: 219000, year: 2024, rating: 4.7, reviews: 38, category: "monoblock", badge: null, specs: ["i7-13700T", "RTX 3060", "32GB", "1TB SSD"], img: "https://images.unsplash.com/photo-1547082299-de196ea013d6?w=600", full: { cpu: "Intel Core i7-13700T", gpu: "NVIDIA RTX 3060 6GB", ram: "32 ГБ DDR5", storage: "1 ТБ SSD", display: "34\" 5K WUHD", os: "Windows 11 Pro" } },
    { id: 22, brand: "NVIDIA", name: "NVIDIA RTX 4080 Super", description: "Топовая видеокарта для 4K", price: 125000, year: 2024, rating: 4.9, reviews: 167, category: "parts", badge: "hot", specs: ["16GB GDDR6X", "320W", "PCIe 4.0", "4K Ready"], img: "https://images.unsplash.com/photo-1587202372616-b43abea06c2a?w=600", full: { type: "Видеокарта", vram: "16 ГБ GDDR6X", tdp: "320W", ports: "3× DP 1.4, HDMI 2.1", length: "304 мм", warranty: "3 года" } },
    { id: 23, brand: "AMD", name: "AMD Ryzen 9 7950X", description: "16-ядерный процессор", price: 58000, year: 2024, rating: 4.8, reviews: 203, category: "parts", badge: null, specs: ["16 ядер", "5.7GHz", "AM5", "170W"], img: "https://images.unsplash.com/photo-1555617981-dac3880eac6e?w=600", full: { type: "Процессор", cores: "16 ядер / 32 потока", freq: "до 5.7 ГГц", socket: "AM5", tdp: "170W", cache: "80 МБ" } },
    { id: 24, brand: "Intel", name: "Intel Core i5-14600K", description: "Отличный процессор для игр", price: 32000, year: 2024, rating: 4.7, reviews: 145, category: "parts", badge: null, specs: ["14 ядер", "5.3GHz", "LGA1700", "125W"], img: "https://images.unsplash.com/photo-1555617981-dac3880eac6e?w=600", full: { type: "Процессор", cores: "14 ядер / 20 потоков", freq: "до 5.3 ГГц", socket: "LGA1700", tdp: "125W", cache: "24 МБ" } },
    { id: 25, brand: "Samsung", name: "Samsung 990 Pro 2TB", description: "Самый быстрый NVMe SSD", price: 22000, year: 2024, rating: 4.9, reviews: 312, category: "parts", badge: "hot", specs: ["2TB NVMe", "7450 МБ/с", "PCIe 4.0", "M.2"], img: "https://images.unsplash.com/photo-1555617981-dac3880eac6e?w=600", full: { type: "SSD", volume: "2 ТБ", speed: "7450 МБ/с", interface: "PCIe 4.0 x4", form: "M.2 2280", warranty: "5 лет" } }
];

const reviews = [
    { name: "Артём", text: "Заказал ROG Strix — привезли за день, собрали, всё работает идеально!", stars: 5, product: "ASUS ROG Strix G16" },
    { name: "Екатерина", text: "Взяла MacBook Pro для монтажа. Пришёл с полным зарядом. Очень довольна!", stars: 5, product: "MacBook Pro 16 M3 Max" },
    { name: "Дмитрий", text: "Собрал ПК через конфигуратор — получилось дешевле, чем готовый.", stars: 5, product: "Сборка ПК" },
    { name: "Максим", text: "Отличный сервис! Заказывал RTX 4080, пришла быстро.", stars: 5, product: "NVIDIA RTX 4080 Super" },
    { name: "Ольга", text: "Купила офисный Dell для работы. Работает тихо, не греется.", stars: 4, product: "Dell OptiPlex 7010" },
    { name: "Сергей", text: "Профессиональная консультация, быстрая доставка. Вернусь ещё!", stars: 5, product: "MSI Titan GT77" }
];

const faqs = [
    { q: "Как оформить заказ?", a: "Добавьте товар в корзину и нажмите «Оформить заказ»." },
    { q: "Какая гарантия?", a: "На все компьютеры — 3 года. На комплектующие — от 1 до 3 лет." },
    { q: "Есть ли доставка?", a: "Бесплатно по Москве в день заказа, по РФ — 1-2 дня." },
    { q: "Можно ли собрать ПК?", a: "Да, используйте конфигуратор. Сборка бесплатная." },
    { q: "Есть ли рассрочка?", a: "Да, 0% до 24 месяцев." }
];

/* ==== СТЕЙТ ==== */
let favorites = JSON.parse(localStorage.getItem("pcshop_favorites")) || [];
let cart = JSON.parse(localStorage.getItem("pcshop_cart")) || [];
let compareList = JSON.parse(localStorage.getItem("pcshop_compare")) || [];
let user = JSON.parse(localStorage.getItem("pcshop_user")) || null;
let orderHistory = JSON.parse(localStorage.getItem("pcshop_history")) || [];
let promoCode = "";
let visibleCount = 8;
let currentFilter = { brand: "all", maxPrice: 500000, sort: "default", search: "", category: "all" };

const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);
const formatPrice = p => p.toLocaleString("ru-RU") + " ₽";

function toast(msg, type = "info") {
    const c = $("#toastContainer");
    const el = document.createElement("div");
    el.className = "toast"; el.textContent = msg;
    if (type === "success") el.style.borderLeftColor = "#10b981";
    if (type === "error") el.style.borderLeftColor = "#ef4444";
    c.appendChild(el);
    setTimeout(() => { el.classList.add("removing"); setTimeout(() => el.remove(), 300); }, 3000);
}

function updateBadges() {
    $("#favCount").textContent = favorites.length;
    $("#cartCount").textContent = cart.length;
    $("#compareCount").textContent = compareList.length;
}

function bumpBadge(selector) {
    const el = $(selector);
    el.classList.remove("bump");
    void el.offsetWidth;
    el.classList.add("bump");
}

/* ==== ИНИЦИАЛИЗАЦИЯ ==== */
window.addEventListener("load", () => {
    setTimeout(() => $("#preloader").classList.add("hide"), 800);
    if (!localStorage.getItem("pcshop_cookies")) {
        setTimeout(() => $("#cookieBanner").classList.add("show"), 1500);
    }
    if (user) updateUserUI();
});
function acceptCookies() { localStorage.setItem("pcshop_cookies", "true"); $("#cookieBanner").classList.remove("show"); }

/* ==== ТЕМА ==== */
const themeToggle = $("#themeToggle");
const savedTheme = localStorage.getItem("pcshop_theme") || "light";
document.documentElement.setAttribute("data-theme", savedTheme);
themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
themeToggle.addEventListener("click", () => {
    const next = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", next);
    themeToggle.textContent = next === "dark" ? "☀️" : "🌙";
    localStorage.setItem("pcshop_theme", next);
});

/* ==== МЕНЮ И ПОИСК ==== */
const nav = $("#nav"); $("#burger").addEventListener("click", () => nav.classList.toggle("open"));
$$(".nav a").forEach(a => a.addEventListener("click", () => nav.classList.remove("open")));
$("#searchToggle").addEventListener("click", () => { $("#searchBar").classList.toggle("open"); if ($("#searchBar").classList.contains("open")) $("#searchInput").focus(); });
$("#searchInput").addEventListener("input", e => { currentFilter.search = e.target.value.toLowerCase().trim(); visibleCount = 8; renderProducts(); });

/* ==== СЛАЙДЕР ==== */
let currentSlide = 0;
const slides = $$(".slide"), dotsContainer = $("#sliderDots");
slides.forEach((_, i) => {
    const dot = document.createElement("button");
    dot.className = "dot" + (i === 0 ? " active" : "");
    dot.addEventListener("click", () => goToSlide(i));
    dotsContainer.appendChild(dot);
});
function goToSlide(index) {
    slides[currentSlide].classList.remove("active"); dotsContainer.children[currentSlide].classList.remove("active");
    currentSlide = (index + slides.length) % slides.length;
    slides[currentSlide].classList.add("active"); dotsContainer.children[currentSlide].classList.add("active");
}
let slideInterval = setInterval(() => goToSlide(currentSlide + 1), 6000);
$("#prevSlide").addEventListener("click", () => { goToSlide(currentSlide - 1); clearInterval(slideInterval); slideInterval = setInterval(() => goToSlide(currentSlide + 1), 6000); });
$("#nextSlide").addEventListener("click", () => { goToSlide(currentSlide + 1); clearInterval(slideInterval); slideInterval = setInterval(() => goToSlide(currentSlide + 1), 6000); });

/* ==== СТАТИСТИКА ==== */
let statsAnimated = false;
function animateStats() {
    if (statsAnimated) return;
    if ($(".stats").getBoundingClientRect().top < window.innerHeight - 100) {
        statsAnimated = true;
        $$(".stat-number").forEach(el => {
            const target = +el.dataset.target;
            let cur = 0;
            const timer = setInterval(() => {
                cur += target / 70;
                if (cur >= target) { el.textContent = target.toLocaleString("ru-RU") + "+"; clearInterval(timer); }
                else el.textContent = Math.floor(cur).toLocaleString("ru-RU");
            }, 20);
        });
    }
}
window.addEventListener("scroll", animateStats); animateStats();

/* ==== ФИЛЬТРЫ ==== */
const brandFilter = $("#brandFilter"), priceFilter = $("#priceFilter"), priceValue = $("#priceValue"), sortFilter = $("#sortFilter");
[...new Set(products.map(p => p.brand))].sort().forEach(b => brandFilter.insertAdjacentHTML("beforeend", `<option value="${b}">${b}</option>`));
brandFilter.addEventListener("change", e => { currentFilter.brand = e.target.value; visibleCount = 8; renderProducts(); });
priceFilter.addEventListener("input", e => { currentFilter.maxPrice = +e.target.value; priceValue.textContent = formatPrice(currentFilter.maxPrice); visibleCount = 8; renderProducts(); });
sortFilter.addEventListener("change", e => { currentFilter.sort = e.target.value; renderProducts(); });
$("#resetFilters").addEventListener("click", () => {
    currentFilter = { brand: "all", maxPrice: 500000, sort: "default", search: "", category: "all" };
    brandFilter.value = "all"; priceFilter.value = 500000; sortFilter.value = "default"; $("#searchInput").value = "";
    priceValue.textContent = formatPrice(500000); visibleCount = 8;
    $$(".category-card").forEach(c => c.classList.remove("active")); $('.category-card[data-category="all"]').classList.add("active");
    renderProducts(); toast("Фильтры сброшены", "success");
});

/* ==== КАТЕГОРИИ ==== */
$$(".category-card").forEach(card => card.addEventListener("click", () => {
    $$(".category-card").forEach(c => c.classList.remove("active"));
    card.classList.add("active");
    currentFilter.category = card.dataset.category;
    visibleCount = 8; renderProducts();
}));

/* ==== РЕНДЕР ТОВАРОВ ==== */
function getFilteredProducts() {
    let res = [...products];
    if (currentFilter.category !== "all") res = res.filter(p => p.category === currentFilter.category);
    if (currentFilter.brand !== "all") res = res.filter(p => p.brand === currentFilter.brand);
    res = res.filter(p => p.price <= currentFilter.maxPrice);
    if (currentFilter.search) res = res.filter(p => (p.name + p.brand + p.description + p.specs.join(" ")).toLowerCase().includes(currentFilter.search));
    if (currentFilter.sort === "price-asc") res.sort((a, b) => a.price - b.price);
    if (currentFilter.sort === "price-desc") res.sort((a, b) => b.price - a.price);
    if (currentFilter.sort === "name") res.sort((a, b) => a.name.localeCompare(b.name));
    if (currentFilter.sort === "rating") res.sort((a, b) => b.rating - a.rating);
    return res;
}

function renderProducts() {
    const grid = $("#carsGrid"), noRes = $("#noResults"), loadBtn = $("#loadMoreBtn");
    const filtered = getFilteredProducts();
    
    if (filtered.length === 0) { grid.innerHTML = ""; noRes.style.display = "block"; loadBtn.style.display = "none"; return; }
    noRes.style.display = "none";

    const toShow = filtered.slice(0, visibleCount);
    grid.innerHTML = toShow.map(p => {
        const isFav = favorites.includes(p.id), isComp = compareList.includes(p.id);
        return `
        <div class="car-card">
            ${p.badge ? `<span class="car-badge ${p.badge}">${p.badge === "hot" ? "🔥 Хит" : "✨ Новинка"}</span>` : ""}
            <button class="car-compare ${isComp ? 'active' : ''}" onclick="toggleCompare(${p.id}, event)">⚖️</button>
            <button class="car-fav ${isFav ? 'active' : ''}" onclick="toggleFavorite(${p.id}, event)">${isFav ? '❤️' : '🤍'}</button>
            <img src="${p.img}" alt="${p.name}" onclick="openProductModal(${p.id})">
            <div class="car-info">
                <div class="car-brand">${p.brand}</div>
                <h3 onclick="openProductModal(${p.id})">${p.name}</h3>
                <div class="car-rating">★★★★★ <span>${p.rating} (${p.reviews})</span></div>
                <div class="car-specs">${p.specs.slice(0, 3).map(s => `<span class="spec-tag">${s}</span>`).join("")}</div>
                <div class="car-footer">
                    <div class="car-price">${formatPrice(p.price)}</div>
                    <button class="btn-cart" onclick="addToCart(${p.id}, this)">В корзину</button>
                </div>
            </div>
        </div>`;
    }).join("");

    loadBtn.style.display = filtered.length > visibleCount ? "inline-block" : "none";
}

$("#loadMoreBtn").addEventListener("click", () => { visibleCount += 8; renderProducts(); });

/* ==== ДЕЙСТВИЯ ==== */
function toggleFavorite(id, e) {
    if (e) e.stopPropagation();
    const idx = favorites.indexOf(id);
    if (idx > -1) { favorites.splice(idx, 1); toast("Удалено из избранного"); }
    else { favorites.push(id); toast("Добавлено в избранное ❤️", "success"); }
    localStorage.setItem("pcshop_favorites", JSON.stringify(favorites));
    updateBadges(); bumpBadge("#favCount"); renderProducts();
}

function toggleCompare(id, e) {
    if (e) e.stopPropagation();
    const idx = compareList.indexOf(id);
    if (idx > -1) { compareList.splice(idx, 1); toast("Удалено из сравнения"); }
    else {
        if (compareList.length >= 3) { toast("Максимум 3 товара для сравнения!", "error"); return; }
        compareList.push(id); toast("Добавлено к сравнению ⚖️", "success");
    }
    localStorage.setItem("pcshop_compare", JSON.stringify(compareList));
    updateBadges(); bumpBadge("#compareCount"); renderProducts();
}

function addToCart(id, btn) {
    if (cart.includes(id)) { toast("Уже в корзине", "info"); return; }
    cart.push(id);
    localStorage.setItem("pcshop_cart", JSON.stringify(cart));
    updateBadges(); bumpBadge("#cartCount");
    if (btn) { btn.textContent = "✅ В корзине"; btn.classList.add("added"); setTimeout(() => { btn.textContent = "В корзину"; btn.classList.remove("added"); }, 2000); }
    toast("Добавлено в корзину 🛒", "success");
}

function removeFromCart(id) {
    cart = cart.filter(c => c !== id);
    localStorage.setItem("pcshop_cart", JSON.stringify(cart));
    updateBadges(); renderCart(); toast("Удалено из корзины");
}

/* ==== МОДАЛКИ ==== */
function openModal(m) { m.classList.add("open"); document.body.style.overflow = "hidden"; }
function closeModal(m) { m.classList.remove("open"); document.body.style.overflow = ""; }

function openProductModal(id) {
    const p = products.find(x => x.id === id); if (!p) return;
    const labels = { cpu: "Процессор", gpu: "Видеокарта", ram: "ОЗУ", storage: "Накопитель", psu: "БП", os: "ОС", type: "Тип", display: "Дисплей", warranty: "Гарантия", cores: "Ядра", freq: "Частота", socket: "Сокет" };
    const fullRows = Object.entries(p.full).map(([k, v]) => `<p><strong>${labels[k] || k}:</strong> ${v}</p>`).join("");
    $("#productModalBody").innerHTML = `
        <img src="${p.img}">
        <h2>${p.name}</h2>
        <p style="margin-bottom:15px;color:var(--text-muted);">${p.description}</p>
        <div style="background:var(--bg);padding:15px;border-radius:10px;margin-bottom:15px;">${fullRows}</div>
        <h3 style="color:var(--primary);font-size:26px;margin-bottom:15px;">${formatPrice(p.price)}</h3>
        <div style="background:var(--bg);padding:15px;border-radius:10px;margin-bottom:15px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;">
            <strong>💳 Рассрочка 0%:</strong>
            <select id="instSelect" style="padding:8px;border-radius:6px;border:1px solid var(--border);">
                <option value="6">6 мес.</option><option value="12">12 мес.</option><option value="24">24 мес.</option>
            </select>
            <span id="instPrice" style="font-weight:bold;color:var(--primary);">${formatPrice(Math.round(p.price/12))} / мес.</span>
        </div>
        <button class="btn btn-primary" onclick="addToCart(${p.id}); closeModal(document.getElementById('productModal'));" style="width:100%;">🛒 Добавить в корзину</button>
    `;
    setTimeout(() => {
        $("#instSelect").addEventListener("change", e => {
            const m = +e.target.value;
            $("#instPrice").textContent = formatPrice(Math.round(p.price / m)) + " / мес.";
        });
    }, 50);
    openModal($("#productModal"));
}

function renderCompare() {
    const body = $("#compareBody");
    if (compareList.length === 0) { body.innerHTML = "<p>Список сравнения пуст.</p>"; return; }
    const items = compareList.map(id => products.find(p => p.id === id)).filter(Boolean);
    const allKeys = [...new Set(items.flatMap(i => Object.keys(i.full)))];
    const labels = { cpu: "Процессор", gpu: "Видеокарта", ram: "ОЗУ", storage: "Накопитель", psu: "БП", os: "ОС", type: "Тип", display: "Дисплей", warranty: "Гарантия", cores: "Ядра", freq: "Частота", socket: "Сокет" };
    
    let html = `<table class="compare-table"><tr><th>Характеристика</th>`;
    items.forEach(i => html += `<td><img src="${i.img}"><br><b>${i.name}</b><br><span style="color:var(--primary);font-weight:bold;">${formatPrice(i.price)}</span></td>`);
    html += `</tr>`;
    allKeys.forEach(k => {
        html += `<tr><th>${labels[k] || k}</th>`;
        items.forEach(i => html += `<td>${i.full[k] || "—"}</td>`);
        html += `</tr>`;
    });
    html += `</table>`;
    body.innerHTML = html;
}

function renderCart() {
    const body = $("#cartBody");
    if (cart.length === 0) { body.innerHTML = "<p>Корзина пуста 🛒</p>"; return; }
    let total = 0;
    body.innerHTML = cart.map(id => {
        const p = products.find(x => x.id === id); if (!p) return "";
        total += p.price;
        return `<div style="display:flex;align-items:center;gap:15px;padding:12px 0;border-bottom:1px solid var(--border);">
            <img src="${p.img}" style="width:80px;height:60px;object-fit:cover;border-radius:8px;">
            <div style="flex:1;"><strong>${p.name}</strong><br><span style="color:var(--primary);font-weight:bold;">${formatPrice(p.price)}</span></div>
            <button class="icon-btn" onclick="removeFromCart(${p.id})">🗑️</button>
        </div>`;
    }).join("");
    
    let discount = promoCode === "PC10" ? Math.round(total * 0.1) : 0;
    let finalTotal = total - discount;

    body.innerHTML += `
        <div style="margin-top:20px; background:var(--bg); padding:15px; border-radius:10px;">
            <div style="display:flex; gap:10px; margin-bottom:15px;">
                <input type="text" id="promoInput" placeholder="Промокод (PC10)" value="${promoCode}" style="flex:1; padding:10px; border-radius:8px; border:1px solid var(--border); background:var(--bg-card); color:var(--text);">
                <button class="btn btn-outline" onclick="applyPromo()" style="padding:10px 15px;">ОК</button>
            </div>
            ${discount > 0 ? `<p style="color:#10b981; font-weight:bold; margin-bottom:10px;">Скидка: -${formatPrice(discount)}</p>` : ""}
            <h3 style="text-align:right;">Итого: <span style="color:var(--primary);">${formatPrice(finalTotal)}</span></h3>
            <button class="btn btn-primary" style="width:100%;margin-top:10px;" onclick="checkout()">Оформить заказ</button>
        </div>`;
}

function applyPromo() {
    const val = $("#promoInput").value.trim().toUpperCase();
    if (val === "PC10") { promoCode = "PC10"; toast("Промокод применен! Скидка 10%", "success"); }
    else { promoCode = ""; toast("Неверный промокод", "error"); }
    renderCart();
}

function checkout() {
    if (!user) { toast("Войдите в аккаунт, чтобы оформить заказ", "error"); renderUser(); openModal($("#userModal")); return; }
    if (cart.length === 0) { toast("Корзина пуста", "error"); return; }
    
    const orderTotal = cart.reduce((sum, id) => sum + (products.find(p => p.id === id)?.price || 0), 0);
    const discount = promoCode === "PC10" ? Math.round(orderTotal * 0.1) : 0;
    
    const order = {
        date: new Date().toLocaleString("ru-RU"),
        items: [...cart],
        total: orderTotal - discount
    };
    orderHistory.unshift(order);
    localStorage.setItem("pcshop_history", JSON.stringify(orderHistory));
    
    toast("Заказ оформлен! Мы позвоним вам 📞", "success");
    cart = []; promoCode = "";
    localStorage.setItem("pcshop_cart", JSON.stringify(cart));
    updateBadges(); renderCart(); closeModal($("#cartModal"));
}

/* ==== АВТОРИЗАЦИЯ ==== */
function renderUser() {
    const body = $("#userBody");
    if (user) {
        body.innerHTML = `
            <div class="user-info">
                <h3>Привет, ${user.name}! 👋</h3>
                <p style="color:var(--text-muted);font-size:14px;margin-top:5px;">Ваш телефон: ${user.phone || "не указан"}</p>
                <button class="btn btn-outline" style="margin-top:15px;" onclick="logout()">Выйти</button>
            </div>
            <h3 style="margin-bottom:10px;">📜 История заказов</h3>
            <div class="user-history">
                ${orderHistory.length === 0 ? "<p style='color:var(--text-muted);'>Вы еще ничего не заказывали.</p>" : 
                orderHistory.map(o => `<div class="history-item"><div class="history-date">${o.date}</div><b>${o.items.length} товаров на сумму ${formatPrice(o.total)}</b></div>`).join("")}
            </div>
        `;
    } else {
        body.innerHTML = `
            <form id="loginForm" class="contact-form">
                <p style="color:var(--text-muted);margin-bottom:10px;">Войдите, чтобы видеть историю заказов и оформлять покупки в 1 клик.</p>
                <input type="text" id="loginName" placeholder="Ваше имя" required>
                <input type="tel" id="loginPhone" placeholder="Телефон" required>
                <button type="submit" class="btn btn-primary">Войти / Зарегистрироваться</button>
            </form>
        `;
        $("#loginForm").addEventListener("submit", e => {
            e.preventDefault();
            user = { name: $("#loginName").value, phone: $("#loginPhone").value };
            localStorage.setItem("pcshop_user", JSON.stringify(user));
            toast("Добро пожаловать, " + user.name + "!", "success");
            updateUserUI(); renderUser();
        });
    }
}
function logout() { user = null; localStorage.removeItem("pcshop_user"); updateUserUI(); renderUser(); toast("Вы вышли из аккаунта"); }
function updateUserUI() { $("#userBtn").textContent = user ? "👤" : "👤"; $("#userBtn").style.color = user ? "var(--primary)" : "var(--text)"; }

/* ==== КОНФИГУРАТОР ==== */
const buildSelects = { cpu: $("#cpuSelect"), gpu: $("#gpuSelect"), ram: $("#ramSelect"), storage: $("#storageSelect"), psu: $("#psuSelect") };

function updateBuild() {
    const list = $("#buildList"); let items = []; let total = 0;
    Object.entries(buildSelects).forEach(([k, sel]) => {
        const opt = sel.options[sel.selectedIndex]; const price = +opt.dataset.price;
        if (price > 0) { items.push({ k, label: opt.textContent.split(" — ")[0], price }); total += price; }
    });
    list.innerHTML = items.length === 0 ? '<li class="empty">Комплектующие не выбраны</li>' : items.map(i => `<li><span>${i.label}</span><span class="item-price">${formatPrice(i.price)}</span></li>`).join("");
    $("#buildTotal").textContent = formatPrice(total);

    // Проверка совместимости
    const cpuSocket = buildSelects.cpu.options[buildSelects.cpu.selectedIndex].dataset.socket;
    const alertEl = $("#compatibilityAlert");
    if (cpuSocket === "LGA1700" && buildSelects.cpu.selectedIndex > 0) {
        alertEl.style.display = "block";
        alertEl.textContent = "⚠️ Выбран процессор Intel. Убедитесь, что материнская плата поддерживает LGA1700!";
    } else {
        alertEl.style.display = "none";
    }
}
Object.values(buildSelects).forEach(s => s.addEventListener("change", updateBuild));
$("#resetBuild").addEventListener("click", () => { Object.values(buildSelects).forEach(s => s.selectedIndex = 0); updateBuild(); toast("Сборка сброшена"); });
$("#addBuildToCart").addEventListener("click", () => {
    const total = parseInt($("#buildTotal").textContent.replace(/\D/g, ""));
    if (total === 0) { toast("Выберите компоненты", "error"); return; }
    toast("Сборка добавлена в заказ! Мы свяжемся с вами 🛠️", "success");
    Object.values(buildSelects).forEach(s => s.selectedIndex = 0); updateBuild();
});

/* ==== ОТЗЫВЫ И FAQ ==== */
function renderReviews() {
    $("#reviewsGrid").innerHTML = reviews.map(r => `
        <div class="review-card">
            <div class="review-header">
                <div class="review-avatar">${r.name[0]}</div>
                <div><div class="review-name">${r.name}</div><div class="review-stars">${"★".repeat(r.stars)}${"☆".repeat(5 - r.stars)}</div></div>
            </div>
            <p class="review-text">${r.text}</p>
            <div class="review-product">📦 ${r.product}</div>
        </div>
    `).join("");
}
function renderFaq() {
    $("#faqList").innerHTML = faqs.map((f, i) => `
        <div class="faq-item"><button class="faq-question">${f.q}</button><div class="faq-answer">${f.a}</div></div>
    `).join("");
    $$(".faq-question").forEach(btn => btn.addEventListener("click", () => btn.parentElement.classList.toggle("open")));
}

/* ==== ЧАТ ==== */
$("#chatToggle").addEventListener("click", () => $("#chatWidget").classList.toggle("open"));
$("#chatClose").addEventListener("click", () => $("#chatWidget").classList.remove("open"));
$("#chatSend").addEventListener("click", sendChat);
$("#chatInput").addEventListener("keypress", e => { if (e.key === "Enter") sendChat(); });
function sendChat() {
    const input = $("#chatInput"); const txt = input.value.trim(); if (!txt) return;
    const body = $("#chatBody");
    body.insertAdjacentHTML("beforeend", `<div class="chat-msg user">${txt}</div>`);
    input.value = ""; body.scrollTop = body.scrollHeight;
    setTimeout(() => {
        body.insertAdjacentHTML("beforeend", `<div class="chat-msg bot">Спасибо за вопрос! Наш менеджер свяжется с вами в ближайшее время. А пока можете посмотреть наш каталог 😉</div>`);
        body.scrollTop = body.scrollHeight;
    }, 1000);
}

/* ==== СОБЫТИЯ ==== */
$("#favBtn").addEventListener("click", () => { renderFavorites(); openModal($("#favModal")); });
$("#cartBtn").addEventListener("click", () => { renderCart(); openModal($("#cartModal")); });
$("#compareBtn").addEventListener("click", () => { renderCompare(); openModal($("#compareModal")); });
$("#userBtn").addEventListener("click", () => { renderUser(); openModal($("#userModal")); });
$("#openContactModal").addEventListener("click", () => openModal($("#contactModal")));

$("#productModalClose").addEventListener("click", () => closeModal($("#productModal")));
$("#favModalClose").addEventListener("click", () => closeModal($("#favModal")));
$("#cartModalClose").addEventListener("click", () => closeModal($("#cartModal")));
$("#compareModalClose").addEventListener("click", () => closeModal($("#compareModal")));
$("#userModalClose").addEventListener("click", () => closeModal($("#userModal")));
$("#contactModalClose").addEventListener("click", () => closeModal($("#contactModal")));

$$(".modal").forEach(m => m.addEventListener("click", e => { if (e.target === m) closeModal(m); }));
document.addEventListener("keydown", e => { if (e.key === "Escape") $$(".modal.open").forEach(m => closeModal(m)); });

$("#contactForm").addEventListener("submit", e => { e.preventDefault(); toast("Спасибо! Мы свяжемся с вами 💻", "success"); e.target.reset(); });
$("#modalForm").addEventListener("submit", e => { e.preventDefault(); toast("Заявка принята! Перезвоним 📞", "success"); e.target.reset(); closeModal($("#contactModal")); });

window.addEventListener("scroll", () => {
    const st = window.scrollY, dh = document.documentElement.scrollHeight - window.innerHeight;
    $("#scrollProgress").style.width = (st / dh * 100) + "%";
    if (st > 400) $("#scrollTop").classList.add("show"); else $("#scrollTop").classList.remove("show");
});
$("#scrollTop").addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
function scrollToCatalog() { document.getElementById("catalog").scrollIntoView({ behavior: "smooth" }); }

/* ==== ФИНАЛ ==== */
renderProducts(); renderReviews(); renderFaq(); updateBadges(); updateBuild();
priceValue.textContent = formatPrice(500000);
console.log("%c💻 PC SHOP MEGA загружен! Фишек: 10+", "color:#7c3aed;font-size:16px;font-weight:bold;");